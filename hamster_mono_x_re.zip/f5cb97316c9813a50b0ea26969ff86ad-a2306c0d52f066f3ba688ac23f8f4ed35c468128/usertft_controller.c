
void usertft_init_ili(void)

{
  uint uVar1;
  uint controllerCode;
  
  usertft_init();
  gpio_set_pin(PTR_GPIOG_08018ce0,p2);
  probably_wait(100);
  gpio_reset_pin(PTR_GPIOG_08018ce0,p2);
  probably_wait(4000);
  gpio_set_pin(PTR_GPIOG_08018ce0,p2);
  probably_wait(12000);
  sleep(0x32);
  usertft_send_cmd(0);
  usertft_send_value(1);
  sleep(0x32);
  usertft_send_cmd(0);
  maybe_SysTick_Config(5);
  usertft_read2();
                    /* Read ID4 
                        */
  usertft_send_cmd(0xd3);
  usertft_read2();
  usertft_read2();
  uVar1 = usertft_read2();
  controllerCode = usertft_read2();
  controllerCode = (uVar1 & 0xff) << 8 | controllerCode;
  if (controllerCode != 0x9488) {
    usertft_send_cmd(0xb0);
    usertft_send_value(0);
    usertft_send_cmd(0xbf);
    usertft_read2();
    usertft_read2();
    usertft_read2();
    uVar1 = usertft_read2();
    controllerCode = usertft_read2();
    controllerCode = (uVar1 & 0xff) << 8 | controllerCode;
  }
  if (controllerCode == 0x1581) {
    usertft_send_cmd(0xff);
    usertft_send_cmd(0xff);
    sleep(5);
    usertft_send_cmd(0xff);
    usertft_send_cmd(0xff);
    usertft_send_cmd(0xff);
    usertft_send_cmd(0xff);
    sleep(10);
    usertft_send_cmd(0x11);
    sleep(0x96);
    usertft_send_cmd(0xb0);
    usertft_send_value(0);
    usertft_send_cmd(0xb3);
    usertft_send_value(2);
    usertft_send_value(0);
    usertft_send_value(0);
    usertft_send_value(0);
    usertft_send_cmd(0xb4);
    usertft_send_value(0);
    usertft_send_cmd(0xc0);
    usertft_send_value(3);
    usertft_send_value(0x3b);
    usertft_send_value(0);
    usertft_send_value(0);
    usertft_send_value(0);
    usertft_send_value(1);
    usertft_send_value(0);
    usertft_send_value(0x22);
    usertft_send_cmd(0xc1);
    usertft_send_value(8);
    usertft_send_value(0x1d);
    usertft_send_value(8);
    usertft_send_value(8);
    usertft_send_cmd(0xc4);
    usertft_send_value(0x11);
    usertft_send_value(5);
    usertft_send_value(0x23);
    usertft_send_value(3);
    usertft_send_cmd(200);
    usertft_send_value(1);
    usertft_send_value(7);
    usertft_send_value(0xd);
    usertft_send_value(0x79);
    usertft_send_value(8);
    usertft_send_value(0xc);
    usertft_send_value(0xc);
    usertft_send_value(1);
    usertft_send_value(0);
    usertft_send_value(0x32);
    usertft_send_value(1);
    usertft_send_value(0xc);
    usertft_send_value(0xc);
    usertft_send_value(0x78);
    usertft_send_value(9);
    usertft_send_value(0xd);
    usertft_send_value(7);
    usertft_send_value(1);
    usertft_send_value(0x32);
    usertft_send_value(0);
    usertft_send_cmd(0xd0);
    usertft_send_value(7);
    usertft_send_value(4);
    usertft_send_value(0x1d);
    usertft_send_value(2);
    usertft_send_cmd(0xd1);
    usertft_send_value(3);
    usertft_send_value(0x3a);
    usertft_send_value(0x11);
    usertft_send_cmd(0xd2);
    usertft_send_value(3);
    usertft_send_value(4);
    usertft_send_value(4);
    usertft_send_cmd(0x36);
    usertft_send_value(0xa0);
    usertft_send_cmd(0x3a);
    usertft_send_value(0x55);
    usertft_send_cmd(0x35);
    usertft_send_value(0);
    usertft_send_cmd(0x44);
    usertft_send_value(0);
    usertft_send_value(1);
    usertft_send_cmd(0x29);
    sleep(0x1e);
    usertft_send_cmd(0x2a);
    usertft_send_value(0);
    usertft_send_value(0);
    usertft_send_value(1);
    usertft_send_value(0x3f);
    usertft_send_cmd(0x2b);
    usertft_send_value(0);
    usertft_send_value(0);
    usertft_send_value(1);
    usertft_send_value(0xdf);
    usertft_send_cmd(0x2c);
    sleep(10);
  }
  else if (controllerCode == 0x9488) {
    usertft_send_cmd(0xe0);
    usertft_send_value(0);
    usertft_send_value(0x13);
    usertft_send_value(0x18);
    usertft_send_value(4);
    usertft_send_value(0xf);
    usertft_send_value(6);
    usertft_send_value(0x3a);
    usertft_send_value(0x56);
    usertft_send_value(0x4d);
    usertft_send_value(3);
    usertft_send_value(10);
    usertft_send_value(6);
    usertft_send_value(0x30);
    usertft_send_value(0x3e);
    usertft_send_value(0xf);
    usertft_send_cmd(0xe1);
    usertft_send_value(0);
    usertft_send_value(0x13);
    usertft_send_value(0x18);
    usertft_send_value(1);
    usertft_send_value(0x11);
    usertft_send_value(6);
    usertft_send_value(0x38);
    usertft_send_value(0x34);
    usertft_send_value(0x4d);
    usertft_send_value(6);
    usertft_send_value(0xd);
    usertft_send_value(0xb);
    usertft_send_value(0x31);
    usertft_send_value(0x37);
    usertft_send_value(0xf);
    usertft_send_cmd(0xc0);
    usertft_send_value(0x18);
    usertft_send_value(0x17);
    usertft_send_cmd(0xc1);
    usertft_send_value(0x41);
    usertft_send_cmd(0xc5);
    usertft_send_value(0);
    usertft_send_value(0x40);
    usertft_send_value(0);
    usertft_send_value(0x40);
    usertft_send_cmd(0x36);
    usertft_send_value(0xaa);
    usertft_send_cmd(0x3a);
    usertft_send_value(0x55);
    usertft_send_cmd(0xb0);
    usertft_send_value(0);
    usertft_send_cmd(0xb1);
    usertft_send_value(0xa0);
    usertft_send_cmd(0xb4);
    usertft_send_value(1);
    usertft_send_cmd(0xb6);
    usertft_send_value(2);
    usertft_send_value(0x22);
    usertft_send_cmd(0xe9);
    usertft_send_value(0);
    usertft_send_cmd(0xf7);
    usertft_send_value(0xa9);
    usertft_send_value(0x51);
    usertft_send_value(0x2c);
    usertft_send_value(0x82);
    usertft_send_cmd(0x20);
    usertft_send_cmd(0x11);
    sleep(0x78);
    usertft_send_cmd(0x29);
    usertft_send_cmd(0x2c);
  }
  else {
    usertft_send_cmd(0xff);
    usertft_send_cmd(0xff);
    sleep(5);
    usertft_send_cmd(0xff);
    usertft_send_cmd(0xff);
    usertft_send_cmd(0xff);
    usertft_send_cmd(0xff);
    sleep(10);
    usertft_send_cmd(0x11);
    sleep(0x96);
    usertft_send_cmd(0xb0);
    usertft_send_value(0);
    usertft_send_cmd(0xb3);
    usertft_send_value(2);
    usertft_send_value(0);
    usertft_send_value(0);
    usertft_send_value(0);
    usertft_send_cmd(0xb4);
    usertft_send_value(0);
    usertft_send_cmd(0xc0);
    usertft_send_value(3);
    usertft_send_value(0x3b);
    usertft_send_value(0);
    usertft_send_value(0);
    usertft_send_value(0);
    usertft_send_value(1);
    usertft_send_value(0);
    usertft_send_value(0x22);
    usertft_send_cmd(0xc1);
    usertft_send_value(8);
    usertft_send_value(0x1d);
    usertft_send_value(8);
    usertft_send_value(8);
    usertft_send_cmd(0xc4);
    usertft_send_value(0x11);
    usertft_send_value(5);
    usertft_send_value(0x23);
    usertft_send_value(3);
    usertft_send_cmd(200);
    usertft_send_value(1);
    usertft_send_value(7);
    usertft_send_value(0xd);
    usertft_send_value(0x79);
    usertft_send_value(8);
    usertft_send_value(0xc);
    usertft_send_value(0xc);
    usertft_send_value(1);
    usertft_send_value(0);
    usertft_send_value(0x32);
    usertft_send_value(1);
    usertft_send_value(0xc);
    usertft_send_value(0xc);
    usertft_send_value(0x78);
    usertft_send_value(9);
    usertft_send_value(0xd);
    usertft_send_value(7);
    usertft_send_value(1);
    usertft_send_value(0x32);
    usertft_send_value(0);
    usertft_send_cmd(0xd0);
    usertft_send_value(7);
    usertft_send_value(4);
    usertft_send_value(0x1d);
    usertft_send_value(2);
    usertft_send_cmd(0xd1);
    usertft_send_value(3);
    usertft_send_value(0x3a);
    usertft_send_value(0x11);
    usertft_send_cmd(0xd2);
    usertft_send_value(3);
    usertft_send_value(4);
    usertft_send_value(4);
    usertft_send_cmd(0x36);
    usertft_send_value(0xa0);
    usertft_send_cmd(0x3a);
    usertft_send_value(0x55);
    usertft_send_cmd(0x35);
    usertft_send_value(0);
    usertft_send_cmd(0x44);
    usertft_send_value(0);
    usertft_send_value(1);
    usertft_send_cmd(0x29);
    sleep(0x1e);
    usertft_send_cmd(0x2a);
    usertft_send_value(0);
    usertft_send_value(0);
    usertft_send_value(1);
    usertft_send_value(0x3f);
    usertft_send_cmd(0x2b);
    usertft_send_value(0);
    usertft_send_value(0);
    usertft_send_value(1);
    usertft_send_value(0xdf);
    usertft_send_cmd(0x2c);
    sleep(10);
  }
  probably_wait(0x4b0);
  usertft_maybe_fill(0x1292);
  gpio_set_pin(PTR_GPIOG_080196e0,p8);
  usertft_send_screen_from_spi2(0x960000);
  return;
}


void usertft_maybe_fill(undefined4 color)

{
  uint uVar1;
  uint uVar2;
  
  usertft_set_mask(0,0,0x1df,0x13f);
  for (uVar1 = 0; uVar1 < 0x140; uVar1 = uVar1 + 1) {
    for (uVar2 = 0; uVar2 < 0x1e0; uVar2 = uVar2 + 1) {
      usertft_sendvalue_rgb(color);
    }
  }
  return;
}


void usertft_set_mask(uint32_t x1,uint32_t y1,uint32_t x2,uint32_t y2)

{
                    /* Column Address Set
                        */
  usertft_send_cmd(0x2a);
  usertft_send_value((x1 << 8) >> 0x10);
  usertft_send_value(x1 & 0xffff);
  usertft_send_value((x2 << 8) >> 0x10);
  usertft_send_value(x2 & 0xffff);
                    /* Page Address Set  */
  usertft_send_cmd(0x2b);
  usertft_send_value((y1 << 8) >> 0x10);
  usertft_send_value(y1 & 0xffff);
  usertft_send_value((y2 << 8) >> 0x10);
  usertft_send_value(y2 & 0xffff);
                    /* Memory Write */
  usertft_send_cmd(0x2c);
  return;
}

