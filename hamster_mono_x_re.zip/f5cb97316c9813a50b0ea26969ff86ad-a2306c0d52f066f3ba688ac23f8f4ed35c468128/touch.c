int touch_do_command(undefined4 param_1)

{
  uint uVar1;
  uint uVar2;
  
  gpio_reset_pin(PTR_GPIOD_0801b768,p12);
  touchwait(2);
  touch_readwrite(param_1);
  touchwait(10);
  uVar1 = touch_readwrite(0);
  uVar2 = touch_readwrite(0);
  gpio_set_pin(PTR_GPIOD_0801b768,p12);
  touchwait(6);
  return (int)((uVar1 & 0xff) << 8 | uVar2) >> 4;
}


uint touch_do_often(undefined4 param_1)

{
  ushort uVar1;
  uint uVar2;
  uint uVar3;
  ushort local_64 [40];
  
  for (uVar2 = 0; uVar2 < 0x28; uVar2 = uVar2 + 1 & 0xffff) {
    uVar1 = touch_do_command(param_1);
    local_64[uVar2] = uVar1;
  }
  uVar3 = 0;
  for (uVar2 = 0; uVar2 < 0x28; uVar2 = uVar2 + 1 & 0xffff) {
    uVar3 = uVar3 + local_64[uVar2];
  }
  return uVar3 / 0x28 & 0xffff;
}


undefined4 touch_get_coords(undefined2 *param_1,undefined2 *param_2)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  
  iVar1 = touch_do_often(0xd0);
  iVar2 = touch_do_often(0x90);
  if ((iVar1 < 10) || (iVar2 < 10)) {
    uVar3 = 0;
  }
  else {
    *param_1 = (short)iVar1;
    *param_2 = (short)iVar2;
    uVar3 = 1;
  }
  return uVar3;
}




uint touch_readwrite(uint param_1)

{
  bool bVar1;
  byte bVar2;
  uint uVar3;
  
  uVar3 = 0;
  gpio_reset_pin(PTR_GPIOD_0801b768,p13);
  touchwait(1);
  for (bVar2 = 0; bVar2 < 8; bVar2 = bVar2 + 1) {
    uVar3 = (uVar3 << 0x19) >> 0x18;
    if ((param_1 & 0x80) == 0) {
      gpio_reset_pin(PTR_GPIOG_0801b76c,p4);
    }
    else {
      gpio_set_pin(PTR_GPIOG_0801b76c,p4);
    }
    gpio_set_pin(PTR_GPIOD_0801b768,p13);
    touchwait(1);
    gpio_reset_pin(PTR_GPIOD_0801b768,p13);
    touchwait(1);
    bVar1 = gpio_read(PTR_GPIOG_0801b76c,p3);
    if (bVar1 != false) {
      uVar3 = uVar3 | 1;
    }
    param_1 = (param_1 << 0x19) >> 0x18;
  }
  return uVar3;
}

